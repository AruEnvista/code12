package com.landmarkgroup.api.returnpolicyenquiry;

import com.landmarkgroup.api.returnpolicyenquiry.model.externalrequestandresponsemodel.ExternalOrderLines;
import com.landmarkgroup.api.returnpolicyenquiry.model.externalrequestandresponsemodel.ExternalOrderRequest;
import com.landmarkgroup.api.returnpolicyenquiry.service.ReturnPolicyValidationService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.stubbing.OngoingStubbing;
import org.reactivestreams.Publisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

import java.util.Arrays;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


@Slf4j
@RunWith(SpringRunner.class)
@WebFluxTest
class ReturnPolicyEnquiryApplicationTests {

    private final ReturnPolicyValidationService returnPolicyValidationService = mock(ReturnPolicyValidationService.class);
    @Autowired
    private WebTestClient webTestClient;

    @Test
    public void orderNotFound() throws Exception {
        ExternalOrderRequest request = new ExternalOrderRequest();
        request.setCustomerOrderId("009009943");
        request.setEnterpriseCode("LMG_UAE / LMG_BAH");
        request.setSource("HYBRIS / POS");
        ExternalOrderLines lines = new ExternalOrderLines();
        lines.setItemId("10000000");
        request.setOrderLines(Arrays.asList(lines));

        Mono<ExternalOrderRequest> monod1 = Mono.just(request);
        Mono<ResponseEntity<ExternalOrderRequest>> d = monod1.map(o1 -> ResponseEntity.status(HttpStatus.OK).body(o1))
                .defaultIfEmpty(ResponseEntity.notFound().build());


        log.info("data is" +
                returnPolicyValidationService.validateOrderForReturns(request.getCustomerOrderId(), request));

        Mockito.when(returnPolicyValidationService
                .validateOrderForReturns(request.getCustomerOrderId(), request))
                .thenReturn(d);

        webTestClient.get()
                .uri("/v3/customer-orders/9099909/events/return-refund-enquiry")
                .exchange()
                .expectStatus().isNotFound();

    }

    @Test
    public void automateAPI() throws Exception {
        ExternalOrderRequest request = new ExternalOrderRequest();
        request.setCustomerOrderId("0090043");
        request.setEnterpriseCode("LMG_UAE");
        request.setSource("HYBRIS");
        ExternalOrderLines lines = new ExternalOrderLines();
        lines.setItemId("10000000");
        lines.setMaximumReturnableQuantity(new java.math.BigDecimal(2));
        request.setOrderLines(Arrays.asList(lines));

        OngoingStubbing<Publisher<ResponseEntity<ExternalOrderRequest>>> result = when(returnPolicyValidationService.validateOrderForReturns(Mockito.any(String.class), Mockito.any(ExternalOrderRequest.class)))
                .thenReturn(Mono.just(request).map(o1 -> ResponseEntity.status(HttpStatus.OK).body(o1)).defaultIfEmpty(ResponseEntity.notFound().build()));

    }


}



