package com.landmarkgroup.api.returnpolicyenquiry.service;

import lombok.extern.slf4j.Slf4j;

import java.net.URISyntaxException;

@Slf4j
public class InvokeService {

    private final ServiceCommandInterface serviceCommandInterface;

    public InvokeService(ServiceCommandInterface serviceCommand) {
        this.serviceCommandInterface = serviceCommand;
    }

    public Object ExecuteRequest() throws URISyntaxException {
        log.info("Start: Service Request");
        return serviceCommandInterface.Execute();
    }
}
