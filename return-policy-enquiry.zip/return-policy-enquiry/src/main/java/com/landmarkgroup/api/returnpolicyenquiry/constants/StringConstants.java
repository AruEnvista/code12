package com.landmarkgroup.api.returnpolicyenquiry.constants;

public class StringConstants {
    public static final String CREATED_STATUS = "Created";

    private StringConstants() {
    }
}
