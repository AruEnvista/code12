package com.landmarkgroup.api.returnpolicyenquiry.exception;

import lombok.*;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class CustomErrorResponse {

    int httpCode;
    String httpMessage;
    String moreInformation;


    public CustomErrorResponse(String httpMessage, String moreInformation, int httpCode) {
        super();
        this.httpMessage = httpMessage;
        this.moreInformation = moreInformation;
        this.httpCode = httpCode;
    }

}