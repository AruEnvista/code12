package com.landmarkgroup.api.returnpolicyenquiry.mapper;

import com.landmarkgroup.api.returnpolicyenquiry.model.externalrequestandresponsemodel.ExternalOrderRequest;
import com.landmarkgroup.api.returnpolicyenquiry.model.omsorderrequestandresponsemodel.OmsReturnOrders;
import com.landmarkgroup.api.returnpolicyenquiry.model.omsorderrequestandresponsemodel.SalesOrderRequest;
import com.landmarkgroup.api.returnpolicyenquiry.model.omsorderrequestandresponsemodel.SalesOrderResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
public class BusinessMapper {

    public SalesOrderRequest mapFromExternalOrderToOMSOrder(ExternalOrderRequest orderRequest, String orderNumber) {
        SalesOrderRequest salesOrder = new SalesOrderRequest();
        salesOrder.setEnterpriseCode(orderRequest.getEnterpriseCode());
        salesOrder.setCustomerOrderNumber(orderNumber);
        salesOrder.setDocumentType("000001");
        return salesOrder;
    }

    public Mono<ExternalOrderRequest> mapFromOMSOrderToExternalOrder(Mono<SalesOrderResponse> omsSalesOrderResponse,
                                                                     ExternalOrderRequest externalOrderRequest) {

        return omsSalesOrderResponse.flatMap(existingProduct -> {
            externalOrderRequest.setCustomerOrderId(existingProduct.getOrderNumber());
            externalOrderRequest.setEnterpriseCode(existingProduct.getEnterpriseCode());
            externalOrderRequest.setIsLegacyOrder(existingProduct.getIsLegacyOrder());
            externalOrderRequest.setSource(existingProduct.getSource());
            externalOrderRequest.setStatus("SUCCESS");//TODO: clarification required: on what basis is the value to be set? and what are the possible values?
            externalOrderRequest.getOrderLines().stream().forEach(line1 -> existingProduct.getOrderLines().stream().forEach(line2 -> {
                if (line1.getItemId().equals(line2.getItemDetails().getItemIdentifier())) {
                    line1.setItemDescription(line2.getItemDetails().getItemIdentifier());
                    line1.setMaximumReturnableQuantity(line2.getReturnableQuantity());
                    line1.setIsReturnable(line2.getIsReturnable());
                    line1.setWithInReturnWindow(line2.getReturnWindowPeriod());
                    line1.setReturnWindowPeriod(line2.getReturnWindowTimePeriod());
                    line1.setOrderedQuantity(line2.getOrderedQuantity());
                    line1.setDepartmentCode(line2.getDepartmentCode());
                    line1.setDeliveryType(line2.getDeliveryType());
                }
            }));
            log.info("values are" + externalOrderRequest);
            return Mono.just(externalOrderRequest).log();
        });
    }


    public SalesOrderResponse validateSalesOrder(SalesOrderResponse omsSalesOrderResponse,
                                                 ExternalOrderRequest externalOrderRequest) {

        if (!omsSalesOrderResponse.getOrderLines().isEmpty()) {
            List<String> externalItemList = new ArrayList<>();
            externalOrderRequest.getOrderLines().stream().forEach(line3 -> externalItemList.add(line3.getItemId()));

            omsSalesOrderResponse.getOrderLines().stream().forEach(line2 -> {
                if (!externalItemList.contains(line2.getItemDetails().getItemIdentifier())) {
                    omsSalesOrderResponse.getOrderLines().remove(line2);
                }
            });

        }
        return omsSalesOrderResponse;
    }

    public SalesOrderResponse validateReturnOrder(OmsReturnOrders omsReturnOrders,
                                                  SalesOrderResponse omsSalesOrderResponse) {

        if (!omsReturnOrders.getReturnOrders().isEmpty()) {
            omsReturnOrders.getReturnOrders().stream().forEach(returnOrder -> {
                if (returnOrder.getRefundInitiatedFlag().equals("N")
                        && omsSalesOrderResponse.getStatusList().contains(returnOrder.getReturnOrderStatus())) {
                    returnOrder.getOrderLines().stream().forEach(returnLine -> omsSalesOrderResponse.getOrderLines().stream().forEach(orderLine -> {
                        if (orderLine.getItemDetails().getItemIdentifier().equals(returnLine.getItemIdentifier())) {
                            orderLine.setReturnableQuantity(orderLine.getReturnableQuantity().intValue() + returnLine.getReturnQuantity().intValue());
                        }
                    }));
                }
            });
        }
        return omsSalesOrderResponse;
    }
}


