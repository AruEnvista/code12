package com.landmarkgroup.api.returnpolicyenquiry.model.omsorderrequestandresponsemodel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
public class OrderStatus {
    @NonNull
    private String status;

    @NonNull
    @Field("status_date")
    private Date statusDate;

    @NonNull
    @Field("status_quantity")
    private Number statusQuantity;
}
